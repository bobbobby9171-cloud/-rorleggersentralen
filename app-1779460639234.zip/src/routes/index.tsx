import { createFileRoute } from '@tanstack/react-router'
import { useMutation } from 'convex/react'
import { api } from '../../convex/_generated/api'
import { useState } from 'react'

export const Route = createFileRoute('/')({
  component: Home,
})

function Home() {
  const createLead = useMutation(api.leads.create)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      await createLead(formData)
      setIsSuccess(true)
      setFormData({ name: '', phone: '', email: '', message: '' })
    } catch (error) {
      console.error(error)
      alert('Noe gikk galt. Vennligst prøv igjen.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="flex flex-col bg-white text-slate-900 font-sans">
      {/* Hero Section - White & Red Clean */}
      <section className="relative bg-slate-900 text-white overflow-hidden py-24 lg:py-48">
        <div className="absolute inset-0 z-0 opacity-40">
          <img 
            src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2025/07/LF0A9233-scaled.jpg" 
            alt="Rørleggersentralen Oslo" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <div className="inline-flex items-center gap-2 bg-red-600 text-white px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest mb-8">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse"></span>
              Døgnvakt 24/7 i Oslo
            </div>
            <h1 className="text-5xl md:text-7xl font-black mb-8 leading-tight tracking-tighter uppercase">
              Din rørlegger i Oslo<br />
              <span className="text-red-500 italic">Rask hjelp når det koker.</span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-slate-200 font-medium max-w-2xl leading-relaxed">
              Profesjonell rørleggerservice i over 25 år. Vi rykker ut umiddelbart i hele Oslo og omegn – dag og natt.
            </p>
            <div className="flex flex-wrap gap-6">
              <a 
                href="tel:23035400" 
                className="bg-red-600 text-white px-10 py-5 rounded-lg font-black text-xl hover:bg-red-700 transition-all flex items-center gap-4 uppercase tracking-tight shadow-xl shadow-red-600/20"
              >
                Ring 23 03 54 00
              </a>
              <a 
                href="#bestill" 
                className="bg-white text-slate-900 px-10 py-5 rounded-lg font-black text-xl hover:bg-slate-100 transition-all uppercase tracking-tight shadow-xl"
              >
                Bestill nå
              </a>
            </div>

            <div className="mt-20 flex flex-wrap items-center gap-12 pt-10 border-t border-white/10">
              <div className="flex flex-col">
                <div className="flex text-yellow-400 gap-1 mb-1">
                  {[1,2,3,4,5].map(i => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                  ))}
                </div>
                <span className="text-xs font-black uppercase tracking-widest text-slate-400">4.5/5 stjerner • 240+ kunder</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-red-500"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                </div>
                <span className="font-bold text-sm uppercase">Mesterbedrift</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-red-500"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <span className="font-bold text-sm uppercase">Sentralt Godkjent</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section - Clean White/Red */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end mb-16 gap-8">
            <div className="max-w-2xl">
              <div className="text-red-600 font-black uppercase tracking-widest text-sm mb-4">Fastpriser & Timepriser</div>
              <h2 className="text-4xl md:text-5xl font-black uppercase mb-6 tracking-tighter">Hva koster rørlegger?</h2>
              <p className="text-lg text-slate-600 leading-relaxed font-medium">
                Vi har faste priser på oppmøte og konkurransedyktige timepriser. Alle priser er oversiktlige uten skjulte gebyrer.
              </p>
            </div>
            <div className="bg-red-600 text-white p-10 rounded-2xl shadow-2xl shadow-red-600/20 text-center flex-shrink-0">
              <span className="block text-xs uppercase tracking-widest mb-2 opacity-80 font-bold">Oppmøte fra kun</span>
              <span className="text-5xl font-black tracking-tighter">990,-</span>
              <span className="block text-[10px] uppercase mt-2 opacity-80 font-bold">Ekskl. mva / Oslo & Omegn</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <PriceItem title="Timepris Dag" price="1 250,-" desc="Man-Fre 07:00 - 16:00" />
            <PriceItem title="Timepris Kveld" price="1 875,-" desc="Man-Tor 16:00 - 21:00" />
            <PriceItem title="Vaktutrykning" price="3 500,-" desc="Inkl. 1. time (Kveld/Helg)" />
            <PriceItem title="Befaring" price="0,-" desc="Ved større prosjekter" />
          </div>
          <div className="mt-10 flex items-center gap-2 text-slate-400 italic text-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
            Alle priser er veiledende og ekskl. mva og materiell.
          </div>
        </div>
      </section>

      {/* Services - Updated Images */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20">
            <div className="text-red-600 font-black uppercase tracking-widest text-sm mb-4">Våre Spesialiteter</div>
            <h2 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-4">Tjenester vi utfører</h2>
            <div className="w-20 h-1.5 bg-red-600 mx-auto rounded-full"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <ServiceCard 
              title="Rørleggerservice" 
              image="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2026/04/9H5A0305.jpg"
              description="Vi utfører alt innen rørleggerfaget. Fra kranbytte og reparasjoner til totalrehabilitering av bad og våtrom."
            />
            <ServiceCard 
              title="Spyleavdeling" 
              image="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2022/03/hoytrykkspyling.webp"
              description="Høytrykksspyling av tette rør, rørinspeksjon med kamera og fjerning av røtter. Vi løser de tøffeste blokkeringene."
            />
            <ServiceCard 
              title="Varmepumpe" 
              image="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2022/04/varmepumpe.webp"
              description="Installasjon av Mitsubishi og Toshiba varmepumper. Vi hjelper deg å spare energi med moderne løsninger."
            />
          </div>
        </div>
      </section>

      {/* FAQ Section - Clean White/Red */}
      <section className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-6 max-w-5xl">
          <div className="text-center mb-20">
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tighter mb-4">Ofte stilte spørsmål</h2>
            <p className="text-red-500 font-black uppercase tracking-widest text-sm italic">Svar på det du lurer på</p>
          </div>

          <div className="space-y-4">
            <FaqItem 
              question="Hvor raskt kan dere rykke ut ved vannlekkasje?" 
              answer="Vi har døgnbemannet vakttelefon og rykker ut umiddelbart. Vår responstid i Oslo er normalt under 60 minutter døgnet rundt." 
            />
            <FaqItem 
              question="Er dere en godkjent mesterbedrift?" 
              answer="Ja, Rørleggersentralen er en mesterbedrift, sentralt godkjent for ansvarsrett og godkjent våtromsbedrift. Trygghet for deg som kunde." 
            />
            <FaqItem 
              question="Hva koster en rørlegger i Oslo?" 
              answer="Timeprisen ligger normalt mellom 1100 og 1500 kr ekskl. mva for dagtid. For vaktutrykning tilkommer vaktgebyr og overtidsbetaling." 
            />
            <FaqItem 
              question="Tilbyr dere befaring og prisoverslag?" 
              answer="Ja, vi tilbyr alltid gratis befaring for større oppdrag som badrenovering, rørfornying og varmepumpeinstallasjon." 
            />
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 items-center">
            <div className="lg:col-span-1">
              <div className="text-red-600 font-black uppercase tracking-widest text-sm mb-4">Kundeanmeldelser</div>
              <h2 className="text-5xl font-black uppercase tracking-tighter leading-tight mb-8 text-slate-900">Fornøyde kunder er vårt fokus</h2>
              <div className="flex items-center gap-4 mb-8">
                <span className="text-7xl font-black tracking-tighter text-slate-900">4.5</span>
                <div>
                  <div className="flex text-yellow-400 gap-1 mb-1">
                    {[1,2,3,4,5].map(i => (
                      <svg key={i} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    ))}
                  </div>
                  <p className="text-xs font-black uppercase tracking-widest text-slate-400">240+ anmeldelser på Google</p>
                </div>
              </div>
              <button className="bg-slate-900 text-white px-10 py-5 rounded-lg font-black uppercase tracking-widest hover:bg-slate-800 transition-all w-full lg:w-auto shadow-xl">
                Se alle anmeldelser
              </button>
            </div>
            <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
              <ReviewCard name="Harald Dale-Olsen" text="Hyggelig rørlegger ga full informasjon. Godt utført jobb og ryddig etterpå." />
              <ReviewCard name="Petter Danielsen" text="Sjeldent god service. Profesjonelle ansatte som virkelig kan faget sitt. Helt topp." />
              <ReviewCard name="Jan Petter Mølmann" text="Punktlig oppmøte, ryddige og profesjonelle. ANBEFALES på det sterkeste." />
              <ReviewCard name="Berit Johansen" text="Fikk rask hjelp med tette rør på en søndag kveld. Proff service og hyggelig rørlegger!" />
            </div>
          </div>
        </div>
      </section>

      {/* Certifications - Clean White */}
      <section className="py-20 bg-slate-50 border-y border-slate-100">
        <div className="container mx-auto px-6">
          <div className="flex flex-wrap justify-between items-center gap-12 opacity-80">
            <img src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2025/03/sentralt-godkjent.png" alt="Sentralt Godkjent" className="h-14 md:h-20 object-contain" />
            <img src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2025/03/mestermerket.png" alt="Mestermerket" className="h-14 md:h-20 object-contain" />
            <img src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2025/03/rorentrepenorene.png" alt="Rørentreprenørene" className="h-14 md:h-20 object-contain" />
            <img src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2020/04/miljofyrtarn-sertifisert-virksomhet-vertikal-RGB-150x150.png" alt="Miljøfyrtårn" className="h-14 md:h-20 object-contain" />
            <img src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2025/03/bvnvatrom.png" alt="Våtromsbedrift" className="h-14 md:h-20 object-contain" />
          </div>
        </div>
      </section>

      {/* Contact Form Section - Red Accents */}
      <section id="bestill" className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20">
            <div>
              <div className="text-red-600 font-black uppercase tracking-widest text-sm mb-4">Kontakt oss i dag</div>
              <h2 className="text-5xl font-black uppercase tracking-tighter mb-8 leading-none">Bli kontaktet</h2>
              <p className="text-xl text-slate-600 mb-12 leading-relaxed font-medium">
                Trenger du et pristilbud eller akutt hjelp? Fyll ut skjemaet under, så hører du fra oss før du aner det.
              </p>
              
              <div className="space-y-10">
                <ContactDetail label="Vakttelefon" value="23 03 54 00" sub="Bemannet 24 timer i døgnet" isPrimary />
                <ContactDetail label="E-post" value="post@rorleggersentralen.no" sub="Normal svartid: 1-2 timer" />
                <ContactDetail label="Besøksadresse" value="Lundliveien 11" sub="0584 Oslo" />
              </div>
            </div>

            <div className="bg-white p-8 md:p-12 shadow-[0_40px_80px_-15px_rgba(0,0,0,0.1)] border border-slate-100 rounded-3xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-2 bg-red-600"></div>
              {isSuccess ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12">
                  <div className="w-24 h-24 bg-red-50 text-red-600 rounded-full flex items-center justify-center mb-8">
                    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
                  </div>
                  <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Tusen takk!</h3>
                  <p className="text-slate-600 mb-10 font-bold text-lg">Vi har mottatt din forespørsel og kontakter deg straks.</p>
                  <button onClick={() => setIsSuccess(false)} className="text-red-600 font-black uppercase tracking-widest border-b-4 border-red-100 hover:border-red-600 transition-all text-sm pb-1">Send en ny melding</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <InputField label="Ditt Navn" value={formData.name} onChange={(v: string) => setFormData({...formData, name: v})} placeholder="Navn Navnesen" required />
                    <InputField label="Telefon" type="tel" value={formData.phone} onChange={(v: string) => setFormData({...formData, phone: v})} placeholder="99 88 77 66" required />
                  </div>
                  <InputField label="Din E-post" type="email" value={formData.email} onChange={(v: string) => setFormData({...formData, email: v})} placeholder="navn@epost.no" required />
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400">Hvordan kan vi hjelpe?</label>
                    <textarea 
                      required
                      rows={4} 
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent focus:border-red-600 focus:bg-white rounded-xl outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300"
                      placeholder="Kort beskrivelse av oppdraget..."
                    ></textarea>
                  </div>
                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-red-600 text-white font-black text-xl py-6 rounded-xl hover:bg-red-700 transition-all uppercase tracking-tight disabled:opacity-50 shadow-2xl shadow-red-600/20"
                  >
                    {isSubmitting ? 'Sender forespørsel...' : 'Send forespørsel'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

function ServiceCard({ title, description, image }: { title: string, description: string, image: string }) {
  return (
    <div className="group cursor-pointer">
      <div className="relative overflow-hidden mb-8 aspect-[16/10] rounded-2xl shadow-2xl transition-all duration-700">
        <img src={image} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
      </div>
      <h3 className="text-2xl font-black uppercase tracking-tighter mb-4 group-hover:text-red-600 transition-colors">{title}</h3>
      <p className="text-slate-600 leading-relaxed font-medium mb-6">
        {description}
      </p>
      <div className="inline-flex items-center gap-2 text-red-600 font-black uppercase text-xs tracking-widest group-hover:gap-4 transition-all">
        Les mer om tjenesten
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </div>
    </div>
  )
}

function PriceItem({ title, price, desc }: { title: string, price: string, desc: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:border-red-100 transition-all group">
      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2 group-hover:text-red-500 transition-colors">{title}</h4>
      <div className="text-3xl font-black tracking-tighter mb-2 text-slate-900 italic">{price}</div>
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">{desc}</p>
    </div>
  )
}

function ReviewCard({ name, text }: { name: string, text: string }) {
  return (
    <div className="bg-slate-50 p-10 rounded-2xl border border-slate-100 hover:bg-white hover:shadow-2xl transition-all group">
      <div className="flex gap-0.5 text-yellow-400 mb-6">
        {[1,2,3,4,5].map(i => (
          <svg key={i} xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
        ))}
      </div>
      <p className="text-slate-700 italic mb-8 leading-relaxed font-medium">"{text}"</p>
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-slate-900 text-white rounded-xl flex items-center justify-center font-black italic text-sm group-hover:bg-red-600 transition-colors shadow-lg shadow-slate-900/10">
          {name.charAt(0)}
        </div>
        <span className="font-black uppercase text-[10px] tracking-widest text-slate-900">{name}</span>
      </div>
    </div>
  )
}

function FaqItem({ question, answer }: { question: string, answer: string }) {
  return (
    <details className="group bg-white/5 rounded-2xl overflow-hidden transition-all border border-white/5 hover:border-red-600/30">
      <summary className="flex items-center justify-between cursor-pointer list-none p-8">
        <h3 className="text-xl md:text-2xl font-black uppercase tracking-tighter italic">{question}</h3>
        <span className="bg-red-600 text-white p-2 rounded-lg transition-transform group-open:rotate-45 shadow-lg shadow-red-600/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>
        </span>
      </summary>
      <div className="px-8 pb-8 text-slate-300 text-lg leading-relaxed font-medium border-t border-white/5 pt-6">
        {answer}
      </div>
    </details>
  )
}

function InputField({ label, value, onChange, placeholder, type = 'text', required = false }: any) {
  return (
    <div className="space-y-2">
      <label className="block text-[10px] font-black uppercase tracking-widest text-slate-400">{label}</label>
      <input 
        required={required}
        type={type} 
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-5 py-4 bg-slate-50 border-2 border-transparent focus:border-red-600 focus:bg-white rounded-xl outline-none transition-all font-bold text-slate-900 placeholder:text-slate-300" 
        placeholder={placeholder} 
      />
    </div>
  )
}

function ContactDetail({ label, value, sub, isPrimary = false }: { label: string, value: string, sub: string, isPrimary?: boolean }) {
  return (
    <div className={`p-6 rounded-2xl border ${isPrimary ? 'bg-red-50 border-red-100' : 'bg-slate-50 border-slate-100'}`}>
      <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{label}</h4>
      <div className={`text-3xl font-black tracking-tighter mb-1 italic ${isPrimary ? 'text-red-600' : 'text-slate-900'}`}>{value}</div>
      <p className="text-xs font-bold uppercase tracking-tight text-slate-500">{sub}</p>
    </div>
  )
}
