import { createFileRoute } from '@tanstack/react-router'

export const Route = createFileRoute('/privatkunde')({
  component: Privatkunde,
})

function Privatkunde() {
  return (
    <div className="py-20 container mx-auto px-4">
      <h1 className="text-4xl font-bold text-blue-900 mb-8">Privatkunde</h1>
      <p className="text-lg text-gray-600 leading-relaxed max-w-3xl">
        Vi hjelper privatkunder i hele Oslo med alt fra små rørleggeroppdrag til komplette baderomsrenoveringer. 
        Vår døgnvakt er alltid tilgjengelig hvis det skulle oppstå akutte problemer som vannlekkasjer eller tette rør.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-12">
        <div className="bg-gray-50 p-8 rounded-xl">
          <h2 className="text-2xl font-bold text-blue-900 mb-4">Hva vi kan hjelpe deg med:</h2>
          <ul className="space-y-3">
            <li className="flex items-center gap-2">
              <svg className="text-red-600" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
              Utskifting av kraner og blandebatterier
            </li>
            <li className="flex items-center gap-2">
              <svg className="text-red-600" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
              Installasjon av oppvaskmaskin og vaskemaskin
            </li>
            <li className="flex items-center gap-2">
              <svg className="text-red-600" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
              Reparasjon av toalett og sisterner
            </li>
            <li className="flex items-center gap-2">
              <svg className="text-red-600" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
              Varmtvannsberedere
            </li>
            <li className="flex items-center gap-2">
              <svg className="text-red-600" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
              Modernisering av bad
            </li>
          </ul>
        </div>
        <div className="bg-blue-900 text-white p-8 rounded-xl flex flex-col justify-center">
          <h2 className="text-2xl font-bold mb-4">Trenger du akutt hjelp?</h2>
          <p className="mb-6 opacity-90">Vår vakttelefon er bemannet 24 timer i døgnet, 365 dager i året.</p>
          <a href="tel:23035400" className="bg-red-600 text-white py-4 rounded-lg font-bold text-center text-xl hover:bg-red-700 transition-colors">
            Ring 23 03 54 00
          </a>
        </div>
      </div>
    </div>
  )
}
