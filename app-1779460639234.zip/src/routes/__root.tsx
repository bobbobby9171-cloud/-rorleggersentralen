import {
  HeadContent,
  Outlet,
  Scripts,
  createRootRouteWithContext,
  Link,
} from '@tanstack/react-router'
import * as React from 'react'
import type { QueryClient } from '@tanstack/react-query'
import appCss from '~/styles/app.css?url'
import { ChatBot } from '~/components/ChatBot'

export const Route = createRootRouteWithContext<{
  queryClient: QueryClient
}>()({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: 'Rørleggersentralen | Rørlegger Oslo 24/7',
      },
    ],
    links: [
      { rel: 'stylesheet', href: appCss },
      { rel: 'icon', href: '/favicon.ico' },
    ],
  }),
  notFoundComponent: () => <div>Route not found</div>,
  component: RootComponent,
})

function RootComponent() {
  return (
    <RootDocument>
      <div className="flex flex-col min-h-screen bg-white text-slate-900 font-sans">
        <header className="sticky top-0 z-50 w-full border-b border-slate-100 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
          <div className="container mx-auto flex h-24 items-center justify-between px-6">
            <Link to="/" className="flex items-center gap-3">
              <img 
                src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2021/09/rorlegger-sentralen-logo-2021.png" 
                alt="Rørleggersentralen" 
                className="h-14 grayscale brightness-0" 
              />
            </Link>
            
            <nav className="hidden xl:flex items-center gap-10 text-[11px] font-black uppercase tracking-widest">
              <Link to="/privatkunde" className="transition-all hover:text-red-600 [&.active]:text-red-600">Privatkunde</Link>
              <Link to="/" className="transition-all hover:text-red-600 [&.active]:text-red-600">Borettslag</Link>
              <Link to="/" className="transition-all hover:text-red-600 [&.active]:text-red-600">Næring</Link>
              <Link to="/" className="transition-all hover:text-red-600 [&.active]:text-red-600">Referanser</Link>
              <Link to="/kontakt-oss" className="transition-all hover:text-red-600 [&.active]:text-red-600">Kontakt</Link>
            </nav>

            <div className="flex items-center gap-8">
              <a href="tel:23035400" className="hidden lg:flex flex-col items-end group">
                <span className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-none mb-1 group-hover:text-red-600 transition-colors">Vakttelefon</span>
                <span className="text-2xl font-black text-slate-900 leading-none italic tracking-tighter">23 03 54 00</span>
              </a>
              <Link 
                to="/#bestill" 
                className="bg-red-600 text-white px-8 py-3.5 rounded-lg font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-all shadow-xl shadow-red-600/20"
              >
                Bestill nå
              </Link>
            </div>
          </div>
        </header>

        <main className="flex-1">
          <Outlet />
        </main>

        <ChatBot />

        <footer className="bg-slate-900 text-white py-24">
          <div className="container mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16">
            <div className="space-y-8">
              <img 
                src="https://xn--rrlegger-sentralen-g4b.no/wp-content/uploads/2021/09/rorlegger-sentralen-logo-2021.png" 
                alt="Rørleggersentralen" 
                className="h-12 grayscale brightness-200" 
              />
              <p className="text-slate-400 text-sm font-medium leading-relaxed">
                Din foretrukne rørlegger i Oslo. Vi kombinerer lang erfaring med moderne løsninger og 24/7 beredskap for din trygghet.
              </p>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-10 text-slate-500">Kontaktinfo</h4>
              <ul className="text-xl font-black italic space-y-6">
                <li><a href="tel:23035400" className="hover:text-red-500 transition-all">23 03 54 00</a></li>
                <li className="text-sm not-italic font-medium text-slate-400">Lundliveien 11, 0584 Oslo</li>
                <li className="text-sm not-italic font-medium text-slate-400">post@rorleggersentralen.no</li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-10 text-slate-500">Hurtiglenker</h4>
              <ul className="text-sm font-bold uppercase tracking-widest space-y-4 text-slate-400">
                <li><Link to="/" className="hover:text-white transition-colors">Rørleggerservice</Link></li>
                <li><Link to="/" className="hover:text-white transition-colors">Varmepumper</Link></li>
                <li><Link to="/" className="hover:text-white transition-colors">Spylebil</Link></li>
                <li><Link to="/" className="hover:text-white transition-colors">Borettslag</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-black uppercase tracking-widest mb-10 text-slate-500">Beredskap</h4>
              <div className="bg-white/5 border border-white/5 p-8 rounded-2xl">
                <p className="text-2xl font-black italic mb-2 uppercase text-red-500 leading-none">Døgnvakt</p>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Alle dager • Hele året</p>
              </div>
            </div>
          </div>
          <div className="container mx-auto px-6 mt-24 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">
              &copy; {new Date().getFullYear()} Rørleggersentralen AS • Kvalitet siden 1999
            </p>
            <div className="flex gap-10 grayscale opacity-30">
              <span className="text-[10px] font-black uppercase tracking-widest">Mesterbedrift</span>
              <span className="text-[10px] font-black uppercase tracking-widest">Miljøfyrtårn</span>
              <span className="text-[10px] font-black uppercase tracking-widest">Startbank</span>
            </div>
          </div>
        </footer>
      </div>
    </RootDocument>
  )
}

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  )
}
