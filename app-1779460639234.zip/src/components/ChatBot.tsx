import {
  useUIMessages,
  useSmoothText,
  optimisticallySendMessage,
} from "@convex-dev/agent/react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import type { UIMessage } from "@convex-dev/agent";
import { useState, useEffect, useRef } from "react";

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [threadId, setThreadId] = useState<string | null>(null);
  const createThread = useMutation(api.chat.createThread);

  useEffect(() => {
    const storedThreadId = localStorage.getItem("chatThreadId");
    if (storedThreadId) {
      setThreadId(storedThreadId);
    } else {
      createThread({}).then(({ threadId }) => {
        setThreadId(threadId);
        localStorage.setItem("chatThreadId", threadId);
      });
    }
  }, [createThread]);

  if (!threadId) return null;

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end font-sans">
      {isOpen && (
        <div className="mb-6 w-[350px] sm:w-[450px] h-[650px] bg-white rounded-3xl shadow-[0_30px_100px_rgba(0,0,0,0.2)] border border-slate-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 duration-500">
          {/* Header - White & Red */}
          <div className="bg-white p-8 border-b border-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-red-600 text-white rounded-2xl flex items-center justify-center font-black italic text-xl shadow-lg shadow-red-600/20">
                RS
              </div>
              <div>
                <h3 className="font-black uppercase italic tracking-tighter text-lg leading-none mb-1 text-slate-900">AI Assistent</h3>
                <p className="text-[10px] text-red-600 uppercase tracking-widest font-black flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-pulse"></span>
                  Svarer nå
                </p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="bg-slate-50 text-slate-400 hover:text-slate-900 p-2.5 rounded-xl transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            </button>
          </div>

          {/* Messages */}
          <ChatMessages threadId={threadId} />

          {/* Input */}
          <ChatInput threadId={threadId} />
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-red-600 text-white w-20 h-20 rounded-full shadow-2xl flex items-center justify-center hover:bg-red-700 transition-all hover:scale-105 active:scale-95 group relative shadow-red-600/30"
      >
        {isOpen ? (
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m18 15-6-6-6 6"/></svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        )}
        {!isOpen && (
          <div className="absolute top-0 right-0 -mr-2 -mt-2 bg-white text-red-600 border-2 border-red-600 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full shadow-xl animate-bounce">
            Trenger du hjelp?
          </div>
        )}
      </button>
    </div>
  );
}

function ChatMessages({ threadId }: { threadId: string }) {
  const { results, status, loadMore } = useUIMessages(
    api.chat.listMessages,
    { threadId },
    { initialNumItems: 50, stream: true },
  );
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [results]);

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 bg-slate-50/30">
      <div className="bg-white p-5 rounded-3xl rounded-tl-none text-sm text-slate-700 max-w-[85%] self-start border border-slate-100 shadow-sm font-medium leading-relaxed">
        Hei! Jeg er Rørleggersentralens AI-assistent. Jeg kan svare på spørsmål om priser, tjenester eller hjelpe deg med å bestille rørlegger. Hva kan jeg hjelpe deg med?
      </div>
      
      {results.map((msg) => (
        <Message key={msg.key} message={msg} />
      ))}
    </div>
  );
}

function Message({ message }: { message: UIMessage }) {
  const [visibleText] = useSmoothText(message.text, {
    startStreaming: message.status === "streaming",
  });

  const isAssistant = message.role === "assistant";

  return (
    <div className={`flex flex-col ${isAssistant ? "items-start" : "items-end"}`}>
      <div
        className={`max-w-[90%] p-5 rounded-3xl leading-relaxed text-sm ${
          isAssistant
            ? "bg-white text-slate-800 rounded-tl-none border border-slate-100 shadow-sm font-medium"
            : "bg-red-600 text-white rounded-tr-none shadow-xl shadow-red-600/20 font-bold"
        }`}
      >
        <p className="whitespace-pre-wrap">{visibleText}</p>
        {message.status === "streaming" && (
          <span className="inline-block w-2.5 h-2.5 bg-current rounded-full animate-pulse ml-2" />
        )}
      </div>
      <span className="text-[10px] font-black uppercase tracking-widest text-slate-300 mt-3 px-1">
        {isAssistant ? "Rørleggersentralen AI" : "Deg"}
      </span>
    </div>
  );
}

function ChatInput({ threadId }: { threadId: string }) {
  const [input, setInput] = useState("");
  const sendMessage = useMutation(api.chat.sendMessage).withOptimisticUpdate(
    optimisticallySendMessage(api.chat.listMessages),
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const prompt = input;
    setInput("");
    await sendMessage({ threadId, prompt });
  };

  return (
    <form onSubmit={handleSubmit} className="p-8 bg-white border-t border-slate-50 flex gap-4 items-center">
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Skriv til oss..."
        className="flex-1 bg-slate-50 border-2 border-transparent focus:border-red-600 focus:bg-white rounded-2xl px-6 py-4 text-sm font-bold outline-none transition-all placeholder:text-slate-300"
      />
      <button
        type="submit"
        disabled={!input.trim()}
        className="bg-red-600 text-white p-4 rounded-2xl hover:bg-red-700 disabled:opacity-30 transition-all shadow-xl shadow-red-600/20 active:scale-95"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
      </button>
    </form>
  );
}
