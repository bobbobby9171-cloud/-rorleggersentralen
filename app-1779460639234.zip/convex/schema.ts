import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  leads: defineTable({
    name: v.string(),
    phone: v.string(),
    email: v.string(),
    message: v.string(),
    status: v.string(), // "new", "contacted", "closed"
  }),
  // For the chatbot
  messages: defineTable({
    sessionId: v.string(),
    role: v.union(v.literal("user"), v.literal("assistant")),
    content: v.string(),
  }).index("by_session", ["sessionId"]),
});
