"use node";

import { Agent, createTool } from "@convex-dev/agent";
import { components, api } from "./_generated/api";
import { createOpenRouter } from "@openrouter/ai-sdk-provider";
import { z } from "zod";

const openrouter = createOpenRouter({
  apiKey: process.env.OPENROUTER_API_KEY,
});

export const chatAgent = new Agent(components.agent, {
  name: "Rørleggersentralen AI Assistent",
  instructions: `
    Du er en profesjonell assistent for Rørleggersentralen i Oslo.
    Dine oppgaver er:
    1. Svare på spørsmål om våre tjenester (Rørleggertjenester, Varmepumpe, Spylebil).
    2. Hjelpe kunder med å bestille rørlegger ved å samle navn, telefon, e-post og beskrivelse av problemet.
    3. Gi kontaktinfo: Telefon 23 03 54 00, Adresse Lundliveien 11, 0584 Oslo.
    4. Informere om at vi har døgnvakt 24/7 i hele Oslo, Asker, Bærum, Romerike og Follo.
    
    Vær alltid høflig, profesjonell og hjelpsom. Hvis kunden har en akutt vannlekkasje, be dem ringe vakttelefonen 23 03 54 00 umiddelbart.
  `,
  languageModel: openrouter.chat("openai/gpt-4o-mini"),
  maxSteps: 5,
  tools: {
    bookPlumber: createTool({
      description: "Bestill rørlegger eller send en forespørsel om hjelp.",
      args: z.object({
        name: z.string().describe("Kundens navn"),
        phone: z.string().describe("Kundens telefonnummer"),
        email: z.string().describe("Kundens e-postadresse"),
        message: z.string().describe("Beskrivelse av hva kunden trenger hjelp med"),
      }),
      handler: async (ctx, args): Promise<string> => {
        const leadId = await ctx.runMutation(api.leads.create, args);
        return `Takk! Din forespørsel er mottatt med referanse ${leadId}. En rørlegger vil kontakte deg snart.`;
      },
    }),
  },
});
